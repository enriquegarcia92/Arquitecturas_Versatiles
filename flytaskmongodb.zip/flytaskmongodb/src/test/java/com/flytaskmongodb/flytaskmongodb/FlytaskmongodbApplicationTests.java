package com.flytaskmongodb.flytaskmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlytaskmongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
