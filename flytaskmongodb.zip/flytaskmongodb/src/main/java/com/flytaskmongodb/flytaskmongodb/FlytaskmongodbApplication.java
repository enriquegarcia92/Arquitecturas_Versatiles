package com.flytaskmongodb.flytaskmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlytaskmongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlytaskmongodbApplication.class, args);
	}

}
